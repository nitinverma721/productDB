package com.cognizant.service;

import com.cognizant.entity.Admin;

public interface AdminLoginService {
	
	public boolean doLogin(Admin admin);

}
